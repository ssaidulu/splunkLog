package com.splunklog.dao;

public interface splunkLogDao 
{
public void insertLog();
}
