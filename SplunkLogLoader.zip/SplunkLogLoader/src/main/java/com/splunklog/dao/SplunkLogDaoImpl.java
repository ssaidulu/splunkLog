package com.splunklog.dao;

public class SplunkLogDaoImpl implements splunkLogDao
{

	@Override
	public void insertLog() {
		// TODO Auto-generated method stub
		
	}

}
